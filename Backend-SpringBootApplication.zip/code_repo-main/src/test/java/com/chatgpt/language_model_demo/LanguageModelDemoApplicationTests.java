package com.chatgpt.language_model_demo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LanguageModelDemoApplicationTests {

	@Test
	void contextLoads() {
	}

}

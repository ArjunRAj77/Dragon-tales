package com.chatgpt.requestResponseCommons;

public class ChatMessageDTO {

	private String message;

	public String getMessage() {
		return message;
	}

	public String setMessage(String message) {
		return this.message = message;
	}

}
